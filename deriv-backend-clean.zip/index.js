const express = require('express');
const WebSocket = require('ws');
const app = express();
const port = process.env.PORT || 3000;

// Simple HTTP route
app.get('/', (req, res) => {
  res.send('Deriv API Backend is Live 🚀');
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Connect to Deriv API WebSocket
const ws = new WebSocket('wss://ws.deriv.com/websockets/v3?app_id=76613');

ws.onopen = () => {
  console.log('WebSocket connected to Deriv API ✅');

  // Example request: get active symbols
  ws.send(JSON.stringify({ active_symbols: 'brief', product_type: 'basic' }));
};

ws.onmessage = (msg) => {
  console.log('Deriv API Response: ', msg.data);
};

ws.onerror = (err) => {
  console.error('WebSocket Error:', err.message);
};

ws.onclose = () => {
  console.log('WebSocket connection closed ❌');
};
