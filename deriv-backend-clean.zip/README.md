# Deriv Backend API
A simple Node.js backend connected to the Deriv WebSocket API.
