# ChartBot AI XTrade
A Deriv OAuth trading app.